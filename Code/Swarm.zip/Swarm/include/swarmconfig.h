/* swarmconfig.h.  Generated from swarmconfig.h.in by configure.  */
/* swarmconfig.h.in.  Generated from configure.in by autoheader.  */

/* define if __builtin_apply is buggy */
/* #undef BUGGY_BUILTIN_APPLY */

/* directory for architecutre independent files */
#define DATADIR "${datarootdir}"

/* Define if GUI is disabled. */
/* #undef DISABLE_GUI */

/* Define if SwarmXMLRPC is enables. */
/* #undef ENABLE_XMLRPC */

/* declaration for declaring exported DLL variables */
#define EXPORT_EXTERN extern

/* declaration for defining exported DLL variables */
#define EXPORT_EXTERNDEF 

/* Define to 1 if you have the <argp.h> header file. */
/* #undef HAVE_ARGP_H */

/* Define to 1 if you have the <dlfcn.h> header file. */
/* #undef HAVE_DLFCN_H */

/* defined if HDF5 support is to be available */
#define HAVE_HDF5 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* defined if Java support is to be provided */
/* #undef HAVE_JDK */

/* defined if Java support using Kaffe is to be provided */
/* #undef HAVE_KAFFE */

/* Define to 1 if you have the `memchr' function. */
#define HAVE_MEMCHR 1

/* Define to 1 if you have the `memcpy' function. */
#define HAVE_MEMCPY 1

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if you have the `memset' function. */
#define HAVE_MEMSET 1

/* define if PNG support is to be provided */
#define HAVE_PNG 1

/* Define to 1 if you have the `realpath' function. */
/* #undef HAVE_REALPATH */

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the `stpcpy' function. */
/* #undef HAVE_STPCPY */

/* Define to 1 if you have the `strchr' function. */
#define HAVE_STRCHR 1

/* Define to 1 if you have the `strcmp' function. */
#define HAVE_STRCMP 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the `strlen' function. */
#define HAVE_STRLEN 1

/* Define to 1 if you have the `strncmp' function. */
#define HAVE_STRNCMP 1

/* Define to 1 if you have the `strndup' function. */
/* #undef HAVE_STRNDUP */

/* Define to 1 if you have the `strnlen' function. */
/* #undef HAVE_STRNLEN */

/* Define to 1 if you have the `strpbrk' function. */
#define HAVE_STRPBRK 1

/* Define to 1 if you have the `strsep' function. */
/* #undef HAVE_STRSEP */

/* Define to 1 if you have the `strtoll' function. */
#define HAVE_STRTOLL 1

/* Define to 1 if you have the <sys/sigevent.h> header file. */
/* #undef HAVE_SYS_SIGEVENT_H */

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* define if xpm.h is available */
#define HAVE_X11_XPM_H 1

/* define if nalloc_pixels is available */
#define HAVE_XPM_ALLOCPIXELS 1

/* define if xpm.h is available */
/* #undef HAVE_XPM_H */

/* declaration for importing exported DLL variables */
#define IMPORT_EXTERN extern

/* directory for Swarm include files */
#define INCLUDEDIR "${prefix}/include"

/* subdirectory for includes, if any */
/* #undef INCLUDESUBDIR */

/* define if __int64 needs to be defined for jni.h */
/* #undef JNI_H_NEEDS_INT64 */

/* format for long long type */
#define LLFMT "l"

/* Define to the sub-directory in which libtool stores uninstalled libraries.
   */
#define LT_OBJDIR ".libs/"

/* Are we building against Mac OS X TkAqua? */
/* #undef MAC_OSX_TK */

/* Name of package */
#define PACKAGE "swarm"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "support@swarm.org"

/* Define to the full name of this package. */
#define PACKAGE_NAME "Swarm"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "Swarm 2.4"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "swarm"

/* Define to the version of this package. */
#define PACKAGE_VERSION "2.4"

/* toplevel directory for Swarm installation */
#define PREFIX "/c/swarm"

/* define as format to use for hex pointer */
#define PTRHEXFMT "0x%p"

/* integer comparable in size to a pointer */
#define PTRINT int

/* format for integer comparable in size to a pointer */
#define PTRINTFMT "%d"

/* unsigned integer comparable in size to a pointer */
#define PTRUINT unsigned

/* format for unsigned integer comparable in size to a pointer */
#define PTRUINTFMT "%u"

/* The size of `int', as computed by sizeof. */
#define SIZEOF_INT 4

/* The size of `long', as computed by sizeof. */
#define SIZEOF_LONG 4

/* The size of `long long', as computed by sizeof. */
#define SIZEOF_LONG_LONG 8

/* The size of `void *', as computed by sizeof. */
#define SIZEOF_VOID_P 4

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* type of integer that is 64 bits */
#define SWARM_INT64 long long

/* directory for Swarm Makefile templates */
#define SYSCONFDIR "${prefix}/etc"

/* define if avcall will be used */
/* #undef USE_AVCALL */

/* Define if mframe functions to be used. */
#define USE_MFRAME 1

/* Version number of package */
#define VERSION "2.4.1"

/* Define to 1 if the X Window System is missing or not being used. */
#define X_DISPLAY_MISSING 1
